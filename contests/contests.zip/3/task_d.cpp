// Google Style code
#include <iostream>
#include <algorithm>
#include <functional>
#include <vector>
#include <numeric>
#include <set>

struct Edge {
  int cost = 0, start = 0, stop = 0;

  bool operator<(const Edge& other) const {
    return cost < other.cost;
  }
};


class DSU {
  std::vector<int> part = {};
  std::vector<int> deep = {};
  int count_parts = 0;

 public:
  int GetParent(int n) {
    if (part[n] != n) {
      return part[n] = GetParent(part[n]);
    }
    return n;
  }

  DSU(int n) : part(n), deep(n, 0), count_parts(n) {
    std::iota(part.begin(), part.end(), 0);
  }

  void Unite(int a, int b) {
    a = GetParent(a);
    b = GetParent(b);

    if (a != b) {
      if (deep[a] < deep[b]) {
        std::swap(a, b);
      }
      --count_parts;
      part[b] = a;
      if (deep[a] == deep[b]) {
        ++deep[a];
      }
    }
  }
};



int main() {
  int n, m;
  std::cin >> n >> m;

  DSU dsu(n * m);
  std::vector<Edge> edge;

  for (int i = 0; i < n; ++i) {
    for (int j = 0; j < m; ++j) {
      int t;
      std::cin >> t;

      auto is_valid = [](int x_, int y_, int n_, int m_) {
        return x_ < n_ && y_ < m_;
      };

      auto pos = [m](int x, int y) {
        return x * m + y;
      };

      switch (t) {
        case 1:
          dsu.Unite(pos(i, j), pos(i + 1, j));
          if (is_valid(i, j + 1, n, m)) {
            edge.push_back({2, pos(i, j), pos(i, j + 1)});
          }
          break;
          
        case 2:                    
          dsu.Unite(pos(i, j), pos(i, j + 1));
          if (is_valid(i + 1, j, n, m)) {
            edge.push_back({1, pos(i, j), pos(i + 1, j)});
          }
          break;

        case 3:
          dsu.Unite(pos(i, j), pos(i + 1, j));
          dsu.Unite(pos(i, j), pos(i, j + 1));
          break;

        case 0:
          if (is_valid(i, j + 1, n, m)) {
            edge.push_back({2, pos(i, j), pos(i, j + 1)});
          }
          if (is_valid(i + 1, j, n, m)) {
            edge.push_back({1, pos(i, j), pos(i + 1, j)});
          }
          break;

        default:
          break;
      }   
    }
  }

  sort(edge.begin(), edge.end());

  int sum = 0, ans = 0;
  std::vector<Edge> st;
  for (auto i : edge) {
    int mom = dsu.GetParent(i.start);
    int dad = dsu.GetParent(i.stop);

    if (mom != dad) {
      dsu.Unite(mom, dad);
      sum += i.cost;
      ++ans;
      st.push_back(i);
    }
  }

  std::cout << ans << " " << sum << "\n";

  for (auto i : st) {
    std::cout << i.start / m + 1 << " " << i.start % m + 1 << " " << i.cost << "\n";
  }

  return 0;
}