// Google Style Code
#include <iostream>
#include <vector>

class Array {
 public:
  Array(int n): count_elem_(n), array_(n) {}
  
  void ReadFromStream(std::istream& stream) {
    for (auto& elem : array_) {
      stream >> elem;
    }
  }
  
  void HeapSort() {
    for (int i = count_elem_ / 2 - 1; i >= 0; --i) {
      Heapify(count_elem_, i);
    }
    for (int i = count_elem_ - 1; i >= 0; --i) {
      std::swap(array_[0], array_[i]);
      Heapify(i, 0);
    }
  }
  
  void PrintAnswer(std::ostream& stream) const {
    stream << array_[0];
    for (int i = 1; i < count_elem_; ++i) {
      stream << " " << array_[i];
    }
  }

 private:
  void Heapify(int n, int i) {
    int largest = i;   
    int left = 2 * i + 1;
    int right = 2 * i + 2;
    if (left < n && array_[left] > array_[largest]) {
      largest = left;
    }
    if (right < n && array_[right] > array_[largest]) {
      largest = right;
    }
    if (largest != i) {
      std::swap(array_[i], array_[largest]);
      Heapify(n, largest);
    }
  }
  
  int count_elem_;
  std::vector<int> array_;
};

int main() {
    int n;
    std::cin >> n;
    Array array(n);
    
    array.ReadFromStream(std::cin);
    array.HeapSort();
    array.PrintAnswer(std::cout);
    
    return 0;
}