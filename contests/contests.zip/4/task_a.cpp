// Google Style Guide
#include <iostream>
#include <memory>

class Node {
 public:
  Node(int x): data_(x), left_(nullptr), right_(nullptr) {}
      
  int data_;
  std::unique_ptr<Node> left_;
  std::unique_ptr<Node> right_;
};

class Tree {
 public:
  Tree(): height_(0), max_height_(0), tree_(nullptr) {}
  
  void ReadFromStream(std::istream& stream) {
    int i;
    stream >> i;
    while (i) {
      height_ = 0;
      insert(tree_, i);
      if (max_height_ < height_) {
        max_height_ = height_;
      }
      stream >> i;
    }
  }

  int GetMaxHeight() {
    return max_height_;
  }
  
 private:
  void insert(std::unique_ptr<Node>& curr_tree, int n) {
    ++height_; 
    if (curr_tree == nullptr) {
      curr_tree = std::make_unique<Node>(n);
      return;
    }
    if (curr_tree->data_ == n) {
      return;
    }
    if (n < curr_tree->data_) {
      insert(curr_tree->left_, n);
    } else {
      insert(curr_tree->right_, n);
    }
  }
  
  int height_, max_height_;
  std::unique_ptr<Node> tree_;
};

int main() {
  Tree tree;
  tree.ReadFromStream(std::cin);
  std::cout << tree.GetMaxHeight();
  
  return 0;
}