 // Google Style code
#include <iostream>
#include <vector>

class TGraph {
 public:
  TGraph(uint64_t n, uint64_t m): vertex_count_(n), edge_count_(m), graph_(n), reversed_graph_(n) {}
  
  void ReadFromStream(std::istream& stream) { 
    for (uint64_t i = 0; i < edge_count_; ++i) {
      uint64_t a, b;
      stream >> a >> b;
      --a;
      --b;
      bool is_same = false;
      for (auto elem : graph_[a]) {
        if (elem == b) {
          is_same = true;
          break;
        }
      }
      if (!is_same) {
        graph_[a].push_back(b);
        reversed_graph_[b].push_back(a);
      }
    }
  }
  
  std::pair<uint64_t, std::vector<uint64_t>> StrongConnectAndSort() const {
    std::vector<bool> sign(vertex_count_, false);
    std::vector<uint64_t> order;
    for (uint64_t i = 0; i < vertex_count_; ++i) {
      if (!sign[i]) {
        DFSFirst(i, sign, order);
      }
    }
    
    sign.assign(vertex_count_, false);
    uint64_t connected_components = 0;
    std::vector<uint64_t> answer(vertex_count_, 0);
    for (uint64_t i = 0; i < vertex_count_; ++i) {
      std::vector<uint64_t> component;
      int v = order[vertex_count_ - 1 - i];
      if (!sign[v]) {
        connected_components++;
        DFSSecond(v, sign, component);
        for (auto elem : component) {
          answer[elem] = connected_components;
        }
      }
    }
    return std::pair<uint64_t, std::vector<uint64_t>>(connected_components, answer);
  }
  
 private:
  void DFSFirst(uint64_t curr_vertex, std::vector<bool>& sign, std::vector<uint64_t>& order) const {                 
    sign[curr_vertex] = true;
    for (auto elem : graph_[curr_vertex]) {
      if (!sign[elem]) {
        DFSFirst(elem, sign, order);
      }
    }
    order.push_back(curr_vertex);
  }
  
  void DFSSecond(uint64_t curr_vertex, std::vector<bool>& sign, std::vector<uint64_t>& component) const {
    sign[curr_vertex] = true;
    component.push_back(curr_vertex);
    for (auto elem : reversed_graph_[curr_vertex]) {
      if (!sign[elem]) {
        DFSSecond(elem, sign, component);
      }
    }
  }
 
  uint64_t vertex_count_ = 0;
  uint64_t edge_count_ = 0;  
  std::vector<std::vector<uint64_t>> graph_, reversed_graph_;
};

int main() {
  uint64_t n, m;
  std::cin >> n >> m;
  TGraph graph(n, m);
  
  graph.ReadFromStream(std::cin);
  auto [connected_components, answer] = graph.StrongConnectAndSort();
  std::cout << connected_components << std::endl;
  std::cout << answer[0];
  for (size_t i = 1; i < answer.size(); ++i) {
    std::cout << " " << answer[i];
  }
  
  return 0;
}
