#include <iostream>
#include <vector>

class Square {
  public:
  Square(): square_(4, std::vector<uint32_t>(4, 0)) {}

  private:
  std::vector<std::vector<uint32_t>> square_;

}